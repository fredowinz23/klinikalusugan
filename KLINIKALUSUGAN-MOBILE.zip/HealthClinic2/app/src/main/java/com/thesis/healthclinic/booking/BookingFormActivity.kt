package com.thesis.healthclinic.booking

import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.thesis.healthclinic.R
import com.thesis.healthclinic.api.ApiInterface
import com.thesis.healthclinic.api.RetrofitClient
import com.thesis.healthclinic.api.UserSession
import com.thesis.healthclinic.databinding.ActivityBookingFormBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class BookingFormActivity : AppCompatActivity() {

    lateinit var binding: ActivityBookingFormBinding
    var doctorId = 0
    var appointmentDate = ""
    var appointmentTime = ""
    lateinit var bottomSheetDialog: BottomSheetDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBookingFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }

        val myCalendar = Calendar.getInstance()
        val startDateListener = datePickerListener(binding.tvAppointmentDate)

        binding.llDoctor.setOnClickListener {
            showDoctorOptions()
        }

        binding.llAppointmentDate.setOnClickListener {
            DatePickerDialog(this, startDateListener, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding.llAppointmentTime.setOnClickListener {
            if (doctorId==0 || appointmentDate==""){
                Toast.makeText(
                    this@BookingFormActivity,
                    "Enter Doctor and Appointment Date first.",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                showAppointmentSlotOptions()
            }

        }


        binding.btnSubmit.setOnClickListener {
            if (binding.etPurpose.text.isEmpty() || appointmentDate=="" || appointmentTime=="" || doctorId==0){
                Toast.makeText(
                    this@BookingFormActivity,
                    "Fields Must not be empty.",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                submitRequest(binding.etPurpose.text.toString(), appointmentDate, appointmentTime, doctorId)
            }
        }
    }

    private fun showAppointmentSlotOptions() {
        val bottomSheetDialog = BottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.bs_appointment_slot_options)
        val ll8am = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll8am)
        val ll9am = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll9am)
        val ll10am = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll10am)
        val ll11am = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll11am)
        val ll130pm = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll130pm)
        val ll230pm = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll230pm)
        val ll330pm = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll330pm)
        val ll430pm = bottomSheetDialog.findViewById<LinearLayout>(R.id.ll430pm)
        val tv8amAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv8amAvailable)
        val tv9amAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv9amAvailable)
        val tv10amAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv10amAvailable)
        val tv11amAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv11amAvailable)
        val tv130pmAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv130pmAvailable)
        val tv230pmAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv230pmAvailable)
        val tv330pmAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv330pmAvailable)
        val tv430pmAvailable = bottomSheetDialog.findViewById<TextView>(R.id.tv430pmAvailable)
        bottomSheetDialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomSheetDialog.show()


        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val cardioList = AvailableTimeRequest(userSession.username!!,doctorId, appointmentDate)
        val call = retrofitAPI.getAvailableTime(cardioList)

        call.enqueue(object : retrofit2.Callback<AvailableTimeRequest?> {
            override fun onResponse(call: Call<AvailableTimeRequest?>, response: Response<AvailableTimeRequest?>) {

                val responseFromAPI: AvailableTimeRequest? = response.body()
                val avail = responseFromAPI!!.availability

                if (avail!!.slot8am=="NA"){
                    tv8amAvailable!!.text = "Not Available"
                }
                else{
                    ll8am?.setOnClickListener {
                        binding.tvAppointmentTime.text = "8:00AM"
                        appointmentTime = "8:00AM"
                        bottomSheetDialog.hide()
                    }
                }
                if (avail.slot9am=="NA"){
                    tv9amAvailable!!.text = "Not Available"
                }
                else{
                    ll9am?.setOnClickListener {
                        binding.tvAppointmentTime.text = "9:00AM"
                        appointmentTime = "9:00AM"
                        bottomSheetDialog.hide()
                    }
                }
                if (avail.slot10am=="NA"){
                    tv10amAvailable!!.text = "Not Available"
                }
                else{
                    ll10am?.setOnClickListener {
                        binding.tvAppointmentTime.text = "10:00AM"
                        appointmentTime = "10:00AM"
                        bottomSheetDialog.hide()
                    }
                }
                if (avail.slot11am=="NA"){
                    tv11amAvailable!!.text = "Not Available"
                }
                else{
                    ll11am?.setOnClickListener {
                        binding.tvAppointmentTime.text = "11:00AM"
                        appointmentTime = "11:00AM"
                        bottomSheetDialog.hide()
                    }

                }

                if (avail.slot130pm=="NA"){
                    tv130pmAvailable!!.text = "Not Available"
                }
                else{
                    ll130pm?.setOnClickListener {
                        binding.tvAppointmentTime.text = "1:30PM"
                        appointmentTime = "1:30PM"
                        bottomSheetDialog.hide()
                    }
                }

                if (avail.slot230pm=="NA"){
                    tv230pmAvailable!!.text = "Not Available"
                }
                else {
                    ll230pm?.setOnClickListener {
                        binding.tvAppointmentTime.text = "2:30PM"
                        appointmentTime = "2:30PM"
                        bottomSheetDialog.hide()
                    }
                }
                if (avail.slot330pm=="NA"){
                    tv330pmAvailable!!.text = "Not Available"
                }
                else {
                    ll330pm?.setOnClickListener {
                        binding.tvAppointmentTime.text = "3:30PM"
                        appointmentTime = "3:30PM"
                        bottomSheetDialog.hide()
                    }
                }
                if (avail.slot430pm=="NA"){
                    tv430pmAvailable!!.text = "Not Available"
                }
                else {
                    ll430pm?.setOnClickListener {
                        binding.tvAppointmentTime.text = "4:30PM"
                        appointmentTime = "4:30PM"
                        bottomSheetDialog.hide()
                    }
                }

            }

            override fun onFailure(call: Call<AvailableTimeRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@BookingFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }

    private fun showDoctorOptions() {
        bottomSheetDialog = BottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.bs_doctor_options)
        val progressBar = bottomSheetDialog.findViewById<ProgressBar>(R.id.progressBar)
        val counselorOptions = bottomSheetDialog.findViewById<RecyclerView>(R.id.rvCounselorOptions)
        bottomSheetDialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomSheetDialog.show()

        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val cardioList = DoctorListRequest(userSession.username!!)
        val call = retrofitAPI.getDoctorList(cardioList)

        call.enqueue(object : retrofit2.Callback<DoctorListRequest?> {
            override fun onResponse(call: Call<DoctorListRequest?>, response: Response<DoctorListRequest?>) {

                val responseFromAPI: DoctorListRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@BookingFormActivity)
                counselorOptions!!.layoutManager = groupLinear
                val data = responseFromAPI?.doctor_list!!

                val adapter = DoctorListAdapter(this@BookingFormActivity, data)
                counselorOptions.adapter = adapter
            }

            override fun onFailure(call: Call<DoctorListRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@BookingFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }

    private fun datePickerListener(dateInput: TextView): DatePickerDialog.OnDateSetListener {
        val myCalendar = Calendar.getInstance()
        return DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, monthOfYear)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            dateInput.text = year.toString() +"-"+ (monthOfYear+1).toString() +"-"+ dayOfMonth.toString()
            appointmentDate = dateInput.text.toString()
        }
    }

    private fun submitRequest(purpose: String, appointmentDate: String, appointmentTime: String, doctorId: Int) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSubmit.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val userSession = UserSession(this)
        val newBookingRequest = NewBookingRequest(userSession.username!!, purpose,
                                                appointmentDate, appointmentTime, doctorId)
        val call = retrofitAPI.submitBookingRequest(newBookingRequest)

        call.enqueue(object : Callback<NewBookingRequest?> {
            override fun onResponse(call: Call<NewBookingRequest?>, response: Response<NewBookingRequest?>) {
                val responseFromAPI: NewBookingRequest? = response.body()
                finish()
            }

            override fun onFailure(call: Call<NewBookingRequest?>, t: Throwable) {
                Toast.makeText(
                    this@BookingFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSubmit.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }
        })
    }
}
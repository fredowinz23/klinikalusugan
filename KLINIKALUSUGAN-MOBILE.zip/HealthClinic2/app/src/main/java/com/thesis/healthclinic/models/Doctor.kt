package com.thesis.healthclinic.models

import com.google.gson.annotations.SerializedName

data class Doctor(
    @SerializedName("Id")
    var id: Int = 0,

    @SerializedName("firstName")
    var firstName: String = "",

    @SerializedName("lastName")
    var lastName: String = "",

    @SerializedName("specialization")
    var specialization: String = "",
)
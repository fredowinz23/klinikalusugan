package com.thesis.healthclinic.api

import com.thesis.healthclinic.auth.LoginRequest
import com.thesis.healthclinic.booking.AvailableTimeRequest
import com.thesis.healthclinic.booking.BookingListRequest
import com.thesis.healthclinic.booking.DoctorListRequest
import com.thesis.healthclinic.booking.NewBookingRequest
import com.thesis.healthclinic.medcert.MedCertRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("api/login.php")
    fun loginUser(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/change-password.php")
    fun changePassword(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-booking-request.php")
    fun submitBookingRequest(@Body newBookingRequest: NewBookingRequest): Call<NewBookingRequest>

    @Headers("Content-Type: application/json")
    @POST("api/my-booking-list.php")
    fun getMyBookingList(@Body bookingListRequest: BookingListRequest): Call<BookingListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/doctor-list.php")
    fun getDoctorList(@Body doctorListRequest: DoctorListRequest): Call<DoctorListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/doctor-available-time.php")
    fun getAvailableTime(@Body availableTimeRequest: AvailableTimeRequest): Call<AvailableTimeRequest>

    @Headers("Content-Type: application/json")
    @POST("api/med-cert-list.php")
    fun getMedCertList(@Body medCertRequest: MedCertRequest): Call<MedCertRequest>

//    @Headers("Content-Type: application/json")
//    @POST("api/profile.php")
//    fun getProfile(@Body profileInfo: ProfileInfo): Call<ProfileInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/schedule-by-date.php")
//    fun getScheduleInfo(@Body scheduleInfo: ScheduleInfo): Call<ScheduleInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/nurse-schedule-list.php")
//    fun getMyScheduleListInfo(@Body myScheduleListInfo: MyScheduleListInfo): Call<MyScheduleListInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/my-leave-request.php")
//    fun getMyLeaveRequest(@Body leaveInfo: LeaveInfo): Call<LeaveInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/leave-type-list.php")
//    fun getLeaveTypeList(@Body leaveTypeInfo: LeaveTypeInfo): Call<LeaveTypeInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/submit-leave-request.php")
//    fun submitLeaveRequest(@Body leaveRequest: LeaveRequest): Call<LeaveRequest>


}
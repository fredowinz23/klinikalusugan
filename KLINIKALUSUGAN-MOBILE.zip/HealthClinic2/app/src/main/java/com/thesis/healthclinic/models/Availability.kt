package com.thesis.healthclinic.models

import com.google.gson.annotations.SerializedName

data class Availability(
    @SerializedName("slot8am")
    var slot8am: String = "",

    @SerializedName("slot9am")
    var slot9am: String = "",

    @SerializedName("slot10am")
    var slot10am: String = "",

    @SerializedName("slot11am")
    var slot11am: String = "",

    @SerializedName("slot130pm")
    var slot130pm: String = "",

    @SerializedName("slot230pm")
    var slot230pm: String = "",

    @SerializedName("slot330pm")
    var slot330pm: String = "",

    @SerializedName("slot430pm")
    var slot430pm: String = "",

)
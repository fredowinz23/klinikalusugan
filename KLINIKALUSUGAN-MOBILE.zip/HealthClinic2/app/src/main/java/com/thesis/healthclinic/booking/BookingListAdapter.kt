package com.thesis.healthclinic.booking

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.thesis.healthclinic.R
import com.thesis.healthclinic.models.Appointment

class BookingListAdapter(private var context: Context?, private val mList: List<Appointment>) : RecyclerView.Adapter<BookingListAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.adapter_booking, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = mList[position]

        holder.appointmentDate.text = item.appointmentDate
        holder.appointmentTime.text = item.appointmentTime
        holder.purpose.text = item.purpose
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val appointmentDate: TextView = itemView.findViewById(R.id.tvAppointmentDate)
        val appointmentTime: TextView = itemView.findViewById(R.id.tvAppointmentTime)
        val purpose: TextView = itemView.findViewById(R.id.tvPurpose)
        val bookingItem: LinearLayout = itemView.findViewById(R.id.llBookingItem)
    }
}

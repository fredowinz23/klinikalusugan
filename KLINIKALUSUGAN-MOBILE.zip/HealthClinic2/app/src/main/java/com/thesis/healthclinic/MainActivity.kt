package com.thesis.healthclinic

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.thesis.healthclinic.api.UserSession
import com.thesis.healthclinic.auth.LoginActivity
import com.thesis.healthclinic.booking.BookingActivity
import com.thesis.healthclinic.databinding.ActivityMainBinding
import com.thesis.healthclinic.diagnosis.DiagnosisActivity
import com.thesis.healthclinic.medcert.MedCertFormActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.cvNewBooking.setOnClickListener {
            startActivity(Intent(this, BookingActivity::class.java))
        }

        binding.cvAiDiagnosis.setOnClickListener {
            startActivity(Intent(this, DiagnosisActivity::class.java))
        }

        binding.cvMedCert.setOnClickListener {
            startActivity(Intent(this, MedCertFormActivity::class.java))
        }

        binding.cvLogout.setOnClickListener {
            val userSession = UserSession(this)
            userSession.edit?.clear()
            userSession.edit?.apply()
            Log.e("Activity reached", "logout")
            Toast.makeText(
                this,
                "Logged out successfully",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
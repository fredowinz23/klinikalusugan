package com.thesis.healthclinic.diagnosis

data class Spot(
        val id: Long = counter++,
        val name: String
) {
    companion object {
        private var counter = 0L
    }
}

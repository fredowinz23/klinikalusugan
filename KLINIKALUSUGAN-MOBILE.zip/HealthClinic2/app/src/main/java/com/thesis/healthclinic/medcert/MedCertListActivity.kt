package com.thesis.healthclinic.medcert

import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.thesis.healthclinic.R
import com.thesis.healthclinic.api.ApiInterface
import com.thesis.healthclinic.api.RetrofitClient
import com.thesis.healthclinic.api.UserSession
import com.thesis.healthclinic.booking.BookingListAdapter
import com.thesis.healthclinic.booking.BookingListRequest
import com.thesis.healthclinic.databinding.ActivityBookingFormBinding
import com.thesis.healthclinic.databinding.ActivityMedCertListBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class MedCertListActivity : AppCompatActivity() {

    lateinit var binding: ActivityMedCertListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMedCertListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)


        val idNumber = intent.extras?.getString("idNumber", "")

        binding.ivBack.setOnClickListener {
            finish()
        }

        getMedcertList(idNumber!!)

    }

    private fun getMedcertList(idNumber: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val apiRequest = MedCertRequest(idNumber)
        val call = retrofitAPI.getMedCertList(apiRequest)

        call.enqueue(object : retrofit2.Callback<MedCertRequest?> {
            override fun onResponse(call: Call<MedCertRequest?>, response: Response<MedCertRequest?>) {

                binding.progressBar.visibility = View.GONE

                val responseFromAPI: MedCertRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@MedCertListActivity)
                binding.rvList.layoutManager = groupLinear
                val data = responseFromAPI?.booking_list!!

                if (data.isNotEmpty()){
                    binding.tvNoMedCert.visibility = View.GONE
                }
                else{
                    binding.tvNoMedCert.visibility = View.VISIBLE
                }

                val adapter = MedCertListAdapter(this@MedCertListActivity, data)
                binding.rvList.adapter = adapter
            }

            override fun onFailure(call: Call<MedCertRequest?>, t: Throwable) {

                binding.progressBar.visibility = View.GONE

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@MedCertListActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }
}
package com.thesis.healthclinic.diagnosis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.thesis.healthclinic.databinding.ActivityDiagnosisBinding

class DiagnosisActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiagnosisBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDiagnosisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.llStartDiagnosis.setOnClickListener {
            startActivity(Intent(this, DiagnosisFormActivity::class.java))
            finish()
        }
    }
}
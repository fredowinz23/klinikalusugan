package com.thesis.healthclinic.diagnosis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.thesis.healthclinic.databinding.ActivityDiagnosisBinding
import com.thesis.healthclinic.databinding.ActivityDiagnosisResultBinding

class DiagnosisResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiagnosisResultBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDiagnosisResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val flu = intent.extras?.getFloat("flu", 0f)
        val dysmenorrhea = intent.extras?.getFloat("dysmenorrhea", 0f)
        val diarrhea = intent.extras?.getFloat("diarrhea", 0f)
        val soreEyes = intent.extras?.getFloat("soreEyes", 0f)
        val skinAlergy = intent.extras?.getFloat("skinAlergy", 0f)

        binding.tvFlu.text = "$flu %"
        binding.tvDysmenorrhea.text = "$dysmenorrhea %"
        binding.tvDiarrhea.text = "$diarrhea %"
        binding.tvSoreEyes.text = "$soreEyes %"
        binding.tvSkinAllery.text = "$skinAlergy %"

        binding.llClose.setOnClickListener {
            finish()
        }

    }
}
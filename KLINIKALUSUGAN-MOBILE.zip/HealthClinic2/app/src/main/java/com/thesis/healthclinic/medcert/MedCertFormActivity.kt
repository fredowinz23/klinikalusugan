package com.thesis.healthclinic.medcert

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.thesis.healthclinic.MainActivity
import com.thesis.healthclinic.api.UserSession
import com.thesis.healthclinic.api.ApiInterface
import com.thesis.healthclinic.api.RetrofitClient
import com.thesis.healthclinic.databinding.ActivityLoginBinding
import com.thesis.healthclinic.databinding.ActivityMedCertFormBinding
import com.thesis.healthclinic.debug.HostUrlActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MedCertFormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMedCertFormBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMedCertFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.btnSubmit.setOnClickListener {
            if (binding.etIdNumber.text.isEmpty()){
                Toast.makeText(
                    this,
                    "Please Enter ID Number",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                postLoginData(binding.etIdNumber.text.toString())
            }
        }

    }

    private fun postLoginData(idNumber: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSubmit.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val request = MedCertRequest(idNumber)
        val call = retrofitAPI.getMedCertList(request)

        call.enqueue(object : Callback<MedCertRequest?> {
            override fun onResponse(call: Call<MedCertRequest?>, response: Response<MedCertRequest?>) {

                // we are getting response from our body
                // and passing it to our modal class.
                val responseFromAPI: MedCertRequest? = response.body()


                if (responseFromAPI?.success!!){
                    val userSession = UserSession(this@MedCertFormActivity)
                    val intent = Intent(this@MedCertFormActivity, MedCertListActivity::class.java)
                    intent.putExtra("idNumber", idNumber)
                    startActivity(intent)
                    finish()
                }
                else{
                    binding.progressBar.visibility = View.GONE
                    binding.btnSubmit.visibility = View.VISIBLE
                    Toast.makeText(
                        this@MedCertFormActivity,
                        "ID number does not exist",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<MedCertRequest?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.

                Toast.makeText(
                    this@MedCertFormActivity,
                    t.message.toString(),
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSubmit.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }

        })
    }
}
package com.thesis.healthclinic.booking

import com.google.gson.annotations.SerializedName
import com.thesis.healthclinic.models.Appointment

data class BookingListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("status")
    var status: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("booking_list")
    var booking_list: List<Appointment>? = null
)
package com.thesis.healthclinic.booking

import com.google.gson.annotations.SerializedName

data class NewBookingRequest(

    @SerializedName("username")
    var username: String = "",

    @SerializedName("purpose")
    var purpose: String = "",

    @SerializedName("appointmentDate")
    var appointmentDate: String = "",

    @SerializedName("appointmentTime")
    var appointmentTime: String = "",

    @SerializedName("doctorId")
    var doctorId: Int = 0,

    @SerializedName("success")
    var success: String = "",

)
package com.thesis.healthclinic.booking

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.thesis.healthclinic.api.ApiInterface
import com.thesis.healthclinic.api.RetrofitClient
import com.thesis.healthclinic.api.UserSession
import com.thesis.healthclinic.databinding.FragmentBookingBinding
import retrofit2.Call
import retrofit2.Response

class BookingFragment(private val position: Int) : Fragment() {
    private var _binding: FragmentBookingBinding? = null

    private val binding get() = _binding!!

    private var status = "Pending"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentBookingBinding.inflate(inflater, container, false)
        val root: View = binding.root

        status = when (position) {
            0 -> "Pending"
            1 -> "Approved"
            2 -> "Denied"
            else -> "Pending"
        }

        getBookingList(status)

        return root
    }

    private fun getBookingList(leaveStatus: String) {
        val retrofit = RetrofitClient.getInstance(context)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(context)
        val apiRequest = BookingListRequest(userSession.username!!, leaveStatus)
        val call = retrofitAPI.getMyBookingList(apiRequest)

        call.enqueue(object : retrofit2.Callback<BookingListRequest?> {
            override fun onResponse(call: Call<BookingListRequest?>, response: Response<BookingListRequest?>) {

                binding.progressBar.visibility = View.GONE

                val responseFromAPI: BookingListRequest? = response.body()

                val groupLinear = LinearLayoutManager(context)
                binding.rvStoreList.layoutManager = groupLinear
                val data = responseFromAPI?.booking_list!!

                val adapter = BookingListAdapter(context, data)
                binding.rvStoreList.adapter = adapter
            }

            override fun onFailure(call: Call<BookingListRequest?>, t: Throwable) {

                binding.progressBar.visibility = View.GONE

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    context,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }

    override fun onResume() {
        getBookingList(status)
        super.onResume()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
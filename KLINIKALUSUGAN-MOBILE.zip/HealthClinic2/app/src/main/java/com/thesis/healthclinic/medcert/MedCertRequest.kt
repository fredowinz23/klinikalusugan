package com.thesis.healthclinic.medcert

import com.google.gson.annotations.SerializedName
import com.thesis.healthclinic.models.Appointment
import com.thesis.healthclinic.models.User

data class MedCertRequest(
    @SerializedName("idNumber")
    var idNumber: String,

    @SerializedName("success")
    var success: Boolean = false,

    @SerializedName("booking_list")
    var booking_list: List<Appointment>? = null
)
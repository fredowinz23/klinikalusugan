package com.thesis.healthclinic.auth

import com.google.gson.annotations.SerializedName
import com.thesis.healthclinic.models.User

data class LoginRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("password")
    var password: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("user")
    var user: User? = null
)
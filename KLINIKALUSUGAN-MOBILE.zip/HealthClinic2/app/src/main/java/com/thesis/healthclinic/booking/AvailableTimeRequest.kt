package com.thesis.healthclinic.booking

import com.google.gson.annotations.SerializedName
import com.thesis.healthclinic.models.Availability

data class AvailableTimeRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("doctorId")
    var counselorId: Int,

    @SerializedName("appointmentDate")
    var appointmentDate: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("availability")
    var availability: Availability? = null
)
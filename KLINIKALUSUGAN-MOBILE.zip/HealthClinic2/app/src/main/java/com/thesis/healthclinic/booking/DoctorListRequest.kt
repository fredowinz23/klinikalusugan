package com.thesis.healthclinic.booking

import com.google.gson.annotations.SerializedName
import com.thesis.healthclinic.models.Doctor

data class DoctorListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("doctor_list")
    var doctor_list: List<Doctor>? = null
)
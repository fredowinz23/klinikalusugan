<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$booking_list = array();
if (isset($_POST["idNumber"])) {
  $idNumber = $_POST["idNumber"];
  $checkUser = user()->count("idNumber='$idNumber'");
  if ($checkUser>0) {
    // code...
    $user = user()->get("idNumber='$idNumber'");
    $success = true;

    foreach (appointment()->list("studentId=$user->Id and status='Done'") as $row) {
      $item = json_decode(json_encode($row), true);
      array_push($booking_list, $item);
    }

  }
}

$json["idNumber"] = $_POST["idNumber"];
$json["booking_list"] = $booking_list;
$json["success"] = $success;

echo json_encode($json);
?>

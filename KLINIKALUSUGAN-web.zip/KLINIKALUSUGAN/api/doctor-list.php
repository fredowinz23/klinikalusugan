<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;

  $doctor_list = array();

  foreach (doctor()->list() as $row) {
    $item = json_decode(json_encode($row), true);
    array_push($doctor_list, $item);
  }
}

$json["username"] = $_POST["username"];
$json["doctor_list"] = $doctor_list;
$json["success"] = $success;

echo json_encode($json);
?>

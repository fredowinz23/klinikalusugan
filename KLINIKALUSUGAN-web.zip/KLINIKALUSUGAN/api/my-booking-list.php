<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $status = $_POST["status"];
  $user = user()->get("username='$username'");
  $success = true;

  $booking_list = array();

  foreach (appointment()->list("studentId=$user->Id and status='$status'") as $row) {
    $item = json_decode(json_encode($row), true);
    array_push($booking_list, $item);
  }
}

$json["username"] = $_POST["username"];
$json["booking_list"] = $booking_list;
$json["success"] = $success;

echo json_encode($json);
?>

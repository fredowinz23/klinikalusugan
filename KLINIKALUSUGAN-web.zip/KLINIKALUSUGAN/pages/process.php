<?php
session_start();
require_once '../config/database.php';
require_once '../config/Models.php';

$action = $_GET['action'];

switch ($action) {

	case 'user-add' :
		user_add();
		break;

	case 'college-add' :
		college_add();
		break;

	case 'college-delete' :
		college_delete();
		break;

	case 'doctor-add' :
		doctor_add();
		break;

	case 'doctor-delete' :
		doctor_delete();
		break;

	case 'appointment-add' :
		appointment_add();
		break;

	case 'change-app-status' :
		change_app_status();
		break;

	default :
}


function appointment_add(){

	$studentId = $_POST["studentId"];
	$student = user()->get("Id=$studentId");

	$model = appointment();
	$model->obj["createdBy"] = $_SESSION["user_session"]["Id"];
	$model->obj["studentId"] = $_POST["studentId"];
	$model->obj["appointmentDate"] = $_POST["appointmentDate"];
	$model->obj["appointmentTime"] = $_POST["appointmentTime"];
	$model->obj["purpose"] = $_POST["purpose"];
	$model->obj["collegeId"] = $student->collegeId;
	$model->obj["role"] = $student->role;
	$model->obj["status"] = "Approved";
	$model->obj["dateAdded"] = "NOW()";
	$model->create();

	header('Location: appointments.php');
}

function college_add(){

	$model = college();
	$model->obj["code"] = $_POST["code"];
	$model->obj["name"] = $_POST["name"];
	$model->create();

	header('Location: colleges.php');
}

function college_delete(){

	$Id= $_GET["Id"];
	college()->delete("Id=$Id");

	header('Location: colleges.php');
}

function doctor_add(){

	$model = doctor();
	$model->obj["firstName"] = $_POST["firstName"];
	$model->obj["lastName"] = $_POST["lastName"];
	$model->obj["specialization"] = $_POST["specialization"];
	$model->create();

	header('Location: doctors.php');
}

function doctor_delete(){

	$Id= $_GET["Id"];
	doctor()->delete("Id=$Id");

	header('Location: doctors.php');
}

function user_add(){
	$username = $_POST["username"];
	$checkUser = user()->count("username='$username'");

	if ($checkUser>=1) {
		header('Location: user-add.php?role='.$_POST["role"].'&error=Username Already Exists');
	}
	else{
			$model = user();
			$model->obj["username"] = $_POST["username"];
			$model->obj["idNumber"] = $_POST["idNumber"];
			$model->obj["collegeId"] = $_POST["collegeId"];
			$model->obj["firstName"] = $_POST["firstName"];
			$model->obj["role"] = $_POST["role"];
			$model->obj["phone"] = $_POST["phone"];
			$model->obj["email"] = $_POST["email"];
			$model->obj["lastName"] = $_POST["lastName"];
			$model->obj["password"] = $_POST["password"];
			$model->obj["dateAdded"] = "NOW()";
			$model->create();
			header('Location: accounts.php?role=' . $_POST["role"]);
	}
}

function change_app_status(){

	$Id = $_GET["Id"];
	$model = appointment();
	$model->obj["status"] = $_GET["status"];
	$model->update("Id=$Id");

	header('Location: appointment-detail.php?Id=' . $Id);
}

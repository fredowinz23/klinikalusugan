<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
?>

<br>

<h2>USLS Health Clinic Record Keeping with Doctor's Appointment</h2>

<?php include $ROOT_DIR . "templates/footer.php"; ?>

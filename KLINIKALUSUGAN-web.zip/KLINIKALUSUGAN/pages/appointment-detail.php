<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
  $Id = get_query_string("Id", "");
  $app = appointment()->get("Id=$Id");
  $user = user()->get("Id=$app->studentId");
?>

<style media="screen">
  .form-label{
    font-weight: bold;
    color: blue;
  }
  .form-value{
    font-size: 27px;
    margin-left:20px;
  }
</style>


<a href="appointments.php" class="btn btn-warning mb-2">Back</a>

<div class="card" style="min-height:300px;">
  <div class="card-body">
    <div class="row">
      <div class="col-6">
        <div class="form-label">PATIENT NAME:</div>
        <div class="form-value"><?=$user->firstName;?> <?=$user->lastName;?></div>
          <br>
        <div class="form-label">APPOINTMENT DATE:</div>
        <div class="form-value"><?=$app->appointmentDate;?></div>
          <br>
        <div class="form-label">APPOINTMENT TIME:</div>
        <div class="form-value"><?=$app->appointmentTime;?></div>
      </div>
      <div class="col-6">

        <div class="form-label">STATUS:</div>
        <div class="form-value"><?=$app->status;?></div>
        <br>
          <div class="form-label">PURPOSE:</div>
          <div class="form-value"><?=$app->purpose;?></div>
      </div>
      <div class="col-12 mt-3">
        <hr>
        <?php if ($app->status=="Pending"): ?>
          <a href="process.php?action=change-app-status&status=Approved&Id=<?=$Id;?>" class="btn btn-primary">Approve</a>
          <a href="process.php?action=change-app-status&status=Denied&Id=<?=$Id;?>" class="btn btn-danger">Deny</a>
        <?php else: ?>
          <?php if ($app->status=="Approved"): ?>
            <a href="process.php?action=change-app-status&status=Done&Id=<?=$Id;?>" class="btn btn-primary">Done</a>
            <a href="process.php?action=change-app-status&status=No Show&Id=<?=$Id;?>" class="btn btn-danger">No Show</a>
            <a href="process.php?action=change-app-status&status=Pending&Id=<?=$Id;?>" class="btn btn-warning">Change?</a>
            <?php else: ?>
              <a href="process.php?action=change-app-status&status=Pending&Id=<?=$Id;?>" class="btn btn-warning">Change?</a>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
